"""
KdV Convergence Studies
=======================

Visualizes spatial and temporal convergence studies for the Fourier KdV solver.
"""

# %%
# Spatial convergence
# -------------------
# Analyze how error decreases with increasing number of modes.

from __future__ import annotations


import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from spectral.utils.plotting import add_parameter_footer, get_repo_root
from spectral.utils.io import ensure_output_dir
from spectral.utils.formatting import format_dt_latex

repo_root = get_repo_root()
DATA_DIR = repo_root / "data/A2/ex_c"
OUTPUT_DIR = ensure_output_dir(repo_root / "figures/A2/ex_c")

print("Creating spatial convergence plot...")

spatial_path = DATA_DIR / "kdv_spatial_convergence.parquet"
df_spatial = pd.read_parquet(spatial_path)

fig, ax = plt.subplots(figsize=(6.5, 4.5))

sns.lineplot(
    data=df_spatial,
    x="N",
    y="Error",
    hue="method",
    style="dealias",
    markers=True,
    dashes=False,
    linewidth=2,
    markersize=7,
    ax=ax,
)

ax.set_yscale("log")
ax.set_xlabel(r"Number of modes ($N$)")
ax.set_ylabel(r"$L^2$ error")
ax.set_title("Spatial Convergence (Fourier spectral solver)", fontweight="bold")

ax.grid(True, alpha=0.3)
ax.legend(fontsize=8)

# Add parameter footer
N_min_sp = df_spatial["N"].min()
N_max_sp = df_spatial["N"].max()
dt_sp = df_spatial["dt"].iloc[0] if "dt" in df_spatial.columns else None
L_sp = df_spatial["L"].iloc[0] if "L" in df_spatial.columns else None
if dt_sp and L_sp:
    dt_latex = format_dt_latex(dt_sp)
    add_parameter_footer(
        fig,
        rf"$N \in [{N_min_sp}, {N_max_sp}]$, $\Delta t = {dt_latex}$, $L = {L_sp:.1f}$",
    )
elif L_sp:
    add_parameter_footer(fig, rf"$N \in [{N_min_sp}, {N_max_sp}]$, $L = {L_sp:.1f}$")
else:
    add_parameter_footer(fig, rf"$N \in [{N_min_sp}, {N_max_sp}]$")

plt.tight_layout()
spatial_fig = OUTPUT_DIR / "spatial_convergence.pdf"
plt.savefig(spatial_fig, dpi=300, bbox_inches="tight")
print(f"Saved: {spatial_fig}")

# %%
# Temporal convergence
# --------------------
# Analyze convergence in time for different time integrators.

print("Creating temporal convergence plot...")

temporal_path = DATA_DIR / "kdv_temporal_convergence.parquet"
df_temporal = pd.read_parquet(temporal_path)

fig, ax = plt.subplots(figsize=(6.5, 4.5))

sns.lineplot(
    data=df_temporal,
    x="dt",
    y="Error",
    hue="method",
    style="dealias",
    markers=True,
    dashes=False,
    linewidth=2,
    markersize=7,
    ax=ax,
)

ax.set_xscale("log")
ax.set_yscale("log")
ax.invert_xaxis()
ax.set_xlabel(r"Time step $\Delta t$")
ax.set_ylabel(r"$L^2$ error")
ax.set_title("Temporal Convergence (N=128)", fontweight="bold")

ax.grid(True, alpha=0.3)
ax.legend(fontsize=8)

# Add parameter footer
N_temp = df_temporal["N"].iloc[0] if "N" in df_temporal.columns else 128
dt_min_t = df_temporal["dt"].min()
dt_max_t = df_temporal["dt"].max()
L_temp = df_temporal["L"].iloc[0] if "L" in df_temporal.columns else None
dt_min_latex = format_dt_latex(dt_min_t)
dt_max_latex = format_dt_latex(dt_max_t)

if L_temp:
    add_parameter_footer(
        fig,
        rf"$N = {N_temp}$, $\Delta t \in [{dt_min_latex}, {dt_max_latex}]$, $L = {L_temp:.1f}$",
    )
else:
    add_parameter_footer(
        fig, rf"$N = {N_temp}$, $\Delta t \in [{dt_min_latex}, {dt_max_latex}]$"
    )

plt.tight_layout()
temporal_fig = OUTPUT_DIR / "temporal_convergence.pdf"
plt.savefig(temporal_fig, dpi=300, bbox_inches="tight")
print(f"Saved: {temporal_fig}")

print("\nAll plots created successfully!")
