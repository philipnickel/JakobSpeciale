"""
Profiling plots
===============

Visualizes profiling analysis of numerical methods.
"""

# %%
# Performance profiling
# Analyze computational performance characteristics.
