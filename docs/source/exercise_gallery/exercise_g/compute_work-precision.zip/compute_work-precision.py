"""
Work-precision comparison
=========================

Compares computational work versus precision for different methods.
"""

# TODO: Fix error tolerance and then compare work vs precision for different methods
# So basicly tolerance on the x-axis, then two plots: total work vs work pr timestep
