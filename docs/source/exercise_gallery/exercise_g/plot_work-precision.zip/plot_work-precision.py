"""
Work-precision plots
====================

Visualizes computational work versus precision for different methods.
"""

# %%
# Work-precision diagram
# Compare computational cost vs accuracy.
